# tvheadend-iptv-lite (RouterOS arm64)

Slimmed Tvheadend image for MikroTik RB5009 (arm64) /container. IPTV inputs only: UDP/multicast, RTP, HTTP(S).
RTSP is not removed because it lives in the same IPTV module as RTP.

## Removed (compile-time)
linuxdvb (DVB-S/S2, DVB-C/C2, DVB-T/T2, ATSC), SAT>IP client and server, HDHomeRun, tsfile, `pipe://` and `file://`
IPTV handlers (patch 0001), cwc/cccam/capmt/constcw, dvb-scan tables, timeshift, libav (no transcoding), avahi, dbus.
Because libav is disabled, transcoding profiles are unavailable; only passthrough/remux profiles remain.

## Build (pick one)
1. GitHub Actions: copy this folder's contents into the root of `vuducdong/tvheadend` (keep `.github/workflows`),
   commit, run workflow `build-iptv-lite-arm64`, download artifact `tvhead_arm64_lite` (tar + .sha256).
2. Local: `./build.sh` (Linux/macOS) or `./build.ps1` (Windows, Docker Desktop with buildx) from the repo root.

## RouterOS
```
/container/envs/add name=tvh_envs key=TZ value="Asia/Ho_Chi_Minh"
/container/envs/add name=tvh_envs key=TVH_ARGS value="--noacl"
/container/mounts/add name=tvh_config src=usb1-part1/tvh_config dst=/config
/container/add file=usb1-part1/pull/tvhead_arm64_lite.tar interface=veth12 envlist=tvh_envs \
    root-dir=usb1-part1/tvheadend mounts=tvh_config start-on-boot=yes
```
Web UI: `http://<container-ip>:9981`. `--noacl` disables all access control; remove it and create an admin user
if the veth is reachable from untrusted networks. Config path moved from `/etc/tvheadend` to `/config`
(override with `TVH_CONFIG`); copy old config over if you want to keep it.

## Verification status
- Verified: patch 0001 applies cleanly to the supplied `tvheadend-master.zip`; `./configure` accepts all `--disable-*` flags used
  (stopped only at missing `gettext` in the authoring sandbox).
- Not verified: full compile, image size, runtime behaviour on RB5009, busybox `patch` behaviour, the pcloud Vue UI cache download
  at build time. Run a test build and check the first-run log (`tvheadend: IPTV ...`) before replacing the current container.
